#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
#import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from tf.transformations import *
import time
import message_filters

class Mapper:
    def __init__(self):
        #self.scan_sub  = rospy.Subscriber('car_1/scan', LaserScan, self.scanner_callback)
        #self.odom_sub = rospy.Subscriber('car_1/base/odom', Odometry, self.odom_callback)
        self.scan_sub = message_filters.Subscriber('car_1/scan', LaserScan)
        self.odom_sub = message_filters.Subscriber('car_1/base/odom', Odometry)
        self.ats = message_filters.ApproximateTimeSynchronizer([self.scan_sub,self.odom_sub], queue_size=10, slop=0.1)
        self.ats.registerCallback(self.sync)
        self.rate = rospy.Rate(10)
        self.obstacles_x = []
        self.obstacles_y = []
        self.count=0
        self.car_x=[]
        self.car_y=[]
        self.pose = []
        self.twist = []
        self.size=0
        rospy.on_shutdown(self.shutdown)

    def sync(self, scan, odom):
        self.pose.append(odom.pose.pose)
        self.twist.append(odom.twist.twist)

        if self.count == 0:      
            for i,x in enumerate(scan.ranges):
                if x >= scan.range_min and x <= scan.range_max:
                    self.obstacles_x.append(-x*np.cos(scan.angle_min+scan.angle_increment*i))
                    self.obstacles_y.append(-x*np.sin(scan.angle_min+scan.angle_increment*i))
            self.size=len(self.obstacles_x)
            
        else:
            for i,x in enumerate(scan.ranges):
                if x <= 10:
                    self.obstacles_x.append(-x*np.cos(scan.angle_min+scan.angle_increment*i))
                    self.obstacles_y.append(-x*np.sin(scan.angle_min+scan.angle_increment*i))

            
        self.count+=1

    def odom_callback(self, data):  
        #self.rate.sleep()
        self.pose.append(data.pose.pose)
        self.twist.append(data.twist.twist)

    def scanner_callback(self, data):
        #rospy.loginfo("Min Angle: "+str(data.angle_min)+" Max Angle: "+str(data.angle_max)+" Angle Inc: "+str(data.angle_increment))
        #rospy.loginfo((data.angle_max-data.angle_min)/data.angle_increment)
        #rospy.loginfo(len(data.ranges))
        #self.rate.sleep()
        if self.count == 0:      
            for i,x in enumerate(data.ranges):
                if x >= data.range_min and x <= data.range_max:
                    self.obstacles_x.append(-x*np.cos(data.angle_min+data.angle_increment*i))
                    self.obstacles_y.append(-x*np.sin(data.angle_min+data.angle_increment*i))
            self.size=len(self.obstacles_x)
            
        else:
            for i,x in enumerate(data.ranges):
                if x <= 10:
                    self.obstacles_x.append(-x*np.cos(data.angle_min+data.angle_increment*i))
                    self.obstacles_y.append(-x*np.sin(data.angle_min+data.angle_increment*i))

            
        self.count+=1
    
    def shutdown(self):
        rots=rotations(self.pose)
        rc=[]
        for i in range(len(rots)):
            rc.append(np.dot(rots[i],np.array([self.obstacles_x[i],self.obstacles_y[i],0])).tolist())
        print(len(rc))
        rospy.loginfo("Plotting")
                
        f=plt.figure()
        x=[]
        y=[]
        rospy.loginfo(len(m.pose))
        rospy.loginfo(len(rc))
        rospy.loginfo(len(self.obstacles_x))
        for i in range(len(rc)):
            x.append(rc[i][0]-self.pose[i+1].position.x)
            y.append(rc[i][1]-self.pose[i+1].position.y)
        plt.scatter(x,y, color='b')
        plt.scatter([-x.position.x for x in self.pose],[-x.position.y for x in self.pose], color='r')
        plt.show()

    def rotations(self):
        rots=[]
        for i in range(len(self.pose)-1):
            q1 = [self.pose[i].orientation.x, self.pose[i].orientation.y, self.pose[i].orientation.z, -self.pose[i].orientation.w]
            q2 = [self.pose[i+1].orientation.x, self.pose[i+1].orientation.y, self.pose[i+1].orientation.z, self.pose[i+1].orientation.w]
            q = quaternion_multiply(q2,q1)
            r = np.zeros((3,3))
            r[0][0] = 1-2*q[1]**2-2*q[2]**2
            r[1][1] = 1-2*q[0]**2-2*q[2]*2
            r[2][2] = 1-2*q[0]**2-2*q[1]**2
            r[0][1] = 2*q[0]*q[1]-2*q[3]*q[2]
            r[0][2] = 2*q[0]*q[2]+2*q[3]*q[1]
            r[1][0] = 2*q[0]*q[1]+2*q[3]*q[2]
            r[1][2] = 2*q[1]*q[2]-2*q[3]*q[0]
            r[2][0] = 2*q[0]*q[2]-2*q[3]*q[1]
            r[2][1] = 2*q[1]*q[2]+2*q[3]*q[0]
            rots.append(r)
        return rots
    
def rotations(o):
    rots=[]
    for i in range(len(o)-1):
        q1 = [o[i].orientation.x, o[i].orientation.y, o[i].orientation.z, -o[i].orientation.w]
        q2 = [o[i+1].orientation.x, o[i+1].orientation.y, o[i+1].orientation.z, o[i+1].orientation.w]
        q = quaternion_multiply(q2,q1)
        r = np.zeros((3,3))
        r[0][0] = 1-2*q[1]**2-2*q[2]**2
        r[1][1] = 1-2*q[0]**2-2*q[2]*2
        r[2][2] = 1-2*q[0]**2-2*q[1]**2
        r[0][1] = 2*q[0]*q[1]-2*q[3]*q[2]
        r[0][2] = 2*q[0]*q[2]+2*q[3]*q[1]
        r[1][0] = 2*q[0]*q[1]+2*q[3]*q[2]
        r[1][2] = 2*q[1]*q[2]-2*q[3]*q[0]
        r[2][0] = 2*q[0]*q[2]-2*q[3]*q[1]
        r[2][1] = 2*q[1]*q[2]+2*q[3]*q[0]
        rots.append(r)
    return rots



if __name__ == '__main__':
    rospy.init_node('Mapper', anonymous=True)
    m=Mapper()
    #time.sleep(1)
    while 1:
        if len(m.obstacles_x) > m.size:
            break
        else:
            continue
    time.sleep(1)
    plt.scatter(m.obstacles_x[:m.size],m.obstacles_y[:m.size], color='b')
    plt.scatter([0],[0],color='r')
    plt.show()
    #rospy.on_shutdown(shutdown)
    # while not rospy.is_shutdown():
    #     try:
    #         # rots=rotations(m.pose)
    #         # wc=[]
    #         # for i in range(len(rots)):
    #         #     wc.append(np.dot(rots[i],np.array([m.obstacles_x[i],m.obstacles_y[i],0])).tolist())
    #         # print(len(wc))
    #         # while not rospy.is_shutdown():
    #         #     if rospy.is_shutdown():
    #         #         rospy.loginfo("Plotting")
                    
    #         #         f=plt.figure()
    #         #         x=[]
    #         #         y=[]
    #         #         for i in range(len(wc)):
    #         #             x.append(wc[i][0]+m.pose[i+1].position.x)
    #         #             y.append(wc[i][1]+m.pose[i+1].position.y)
    #         #         plt.scatter(x,y, color='b')
    #         #         plt.scatter([x.position.x for x in m.pose],[x.position.y for x in m.pose], color='r')
    #         #         plt.show()
    #         #     continue
    #         pass
    #     except rospy.ROSInterruptException:
    #         rots=rotations(m.pose)
    #         wc=[]
    #         for i in range(len(rots)):
    #             wc.append(np.dot(rots[i],np.array([m.obstacles_x[i],m.obstacles_y[i],0])).tolist())
    #         print(len(wc))
    #         rospy.loginfo("Plotting")
                    
    #         f=plt.figure()
    #         x=[]
    #         y=[]
    #         for i in range(len(wc)):
    #             x.append(wc[i][0]+m.pose[i+1].position.x)
    #             y.append(wc[i][1]+m.pose[i+1].position.y)
    #         plt.scatter(x,y, color='b')
    #         plt.scatter([x.position.x for x in m.pose],[x.position.y for x in m.pose], color='r')
    #         plt.show()
            
    rospy.spin()
    

# def mapper():
#     rospy.init_node('mapper_node', anonymous=True)
#     rate = rospy.Rate(25)

#     # Display the initial plot here

#     while not rospy.is_shutdown():   

#         # Write cummulative mapping logic here 

#         rate.sleep()

# if __name__ == '__main__':
#     try:
#         mapper()
#     except rospy.ROSInterruptException:
#         rospy.loginfo("Plotting")
#         # This block is called if you Ctrl-C the terminal that is running the node
#         # Write your code to display the final plot here

#         pass