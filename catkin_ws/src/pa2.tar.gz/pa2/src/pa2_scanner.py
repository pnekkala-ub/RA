#!/usr/bin/env python3

import rospy
import signal
import random

from sensor_msgs.msg import LaserScan
from std_msgs.msg import Bool

def handler(signum, frame):
    print("Terminating")
    exit(1)

def callback(data):
    danger=False
    for x in data.ranges:
        if x < 5:
            rospy.loginfo("X: "+str(x))
            danger=True
            break
    if danger:
        invokeDriver()
        #ackDrive(2.0,random.choice([-1.0,1.0])*1.57,0.25)

def laserScan():
    rospy.init_node('evader_sensor',anonymous=True)
    rospy.Subscriber('car_1/scan', LaserScan, callback)

def invokeDriver():
    pub = rospy.Publisher('turn', Bool, queue_size=10)
    rospy.init_node('maneuver', anonymous=True)
    pub.publish(True)
    
if __name__ == '__main__':
    signal.signal(signal.SIGINT, handler)
    laserScan()